import React, { Component } from 'react';

export default class AddressComponet extends Component {
 
  onChange(event) {
    if (event.target.value !== this.props.number) {
      this.props.changeAddress(event.target.value,this.refs.input);
	}
  }

  render() {
    return (
	  <div>
		<label>Address (AutoComplete, Type Here) </label>
		<input type='text' id='autocomplete' value={this.props.address} ref='input' autoFocus='true' onChange={this.onChange.bind(this)} />
		<label>Street Name 1 </label>
		<input type='text' value={this.props.street1}/>
		<label>city </label>
		<input type='text' value={this.props.city}/>
		<label>country </label>
		<input type='text' value={this.props.state}/>
		<label>Zipcode </label>
		<input type='text' value={this.props.zipcode}/>
		
	  </div>
	);
  }

}