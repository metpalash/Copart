import React, { Component } from 'react';

export default class PhoneComponet extends Component {
 
  onChange(event) {
    if (event.target.value !== this.props.number) {
      this.props.changeNumber(event.target.value);
	}
  }

  render() {
    return (
	  <div>
	  <label>Phone Number</label>
      <input type='text' value={this.props.number} ref='input' autoFocus='true' onChange={this.onChange.bind(this)} />
	  </div>
	);
  }

}