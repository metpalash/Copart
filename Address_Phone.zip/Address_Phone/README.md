To run code you should have node installed
Type npm install in current directory to download required packages
To start the program type npm start
For more details read package.json