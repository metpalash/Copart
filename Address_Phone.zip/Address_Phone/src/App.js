import React, { Component } from 'react';
import PhoneComponent from './phone_component.js';
import AddressComponent from './address_component.js';

class App extends Component {
  
  constructor(props, context) {
    super(props, context);
    this.state = {
		number: "",
		address: "",
		street1: "",
		city:"",
		state:"",
		zipcode:""
    };
  };
  
  changeNumber(value) {
    var nvalue = "";
    for (var i = 0, len = value.length; i < len; i++) {
		if(value[i]-'0'>=0 && value[i]-'0'<=9) {
			nvalue = nvalue + value[i];
		}
	}
	var s = ""
    if(nvalue.length>0) {
		s = s+"(";
		var k = 0;
		if(nvalue.length<3) k=nvalue.length; 
		else k=3;
		for (i = 0, len = nvalue.length; i<k; i++) {
			s = s + nvalue[i];
		}
		s = s+")";
	}
	if(nvalue.length>2) {
		var count1 = 0;
		var count2 = 0;
		for (i = 3, len = nvalue.length; i < len; i++) {
			if(count1<3) {
				count1++;
			}
			else if(count1==3) {
				count1++;
				s = s+"-";
				count2++;
			}
			else {
				if(count2<4) {
					count2++;
				}
				else if(count2==4) {
					s = s+"-";
					count2=1;
				}
			}
			s = s + nvalue[i];
		}
	}
    this.setState({
      number: s
    });
  }
  
  changeAddress(nadd,input) {
    var placeSearch, autocomplete;
     var componentForm = {
        street_number: 'short_name',
        route: 'long_name',
        locality: 'long_name',
        administrative_area_level_1: 'short_name',
        country: 'long_name',
        postal_code: 'short_name'
    };
	var google = window.google;
	var kk = this;
    function initAutocomplete() {
		var document = window.document
		autocomplete = new google.maps.places.Autocomplete((document.getElementById('autocomplete')),{types: ['geocode']});
		autocomplete.addListener('place_changed', fillInAddress);
    }
	function fillInAddress() {
        var place = autocomplete.getPlace();
        for (var i = 0; i < place.address_components.length; i++) {
          var addressType = place.address_components[i].types[0];
		  console.log(addressType);
          if (componentForm[addressType]) {
            var val = place.address_components[i][componentForm[addressType]];
			console.log(val);
            componentForm[addressType] = val;
          }
		}
		kk.setState({
			address: nadd,
			street1:componentForm['administrative_area_level_1'],
			city:componentForm['locality'],
			state:componentForm['country'],
			zipcode: componentForm['postal_code']
		});
    }
	function geolocate() {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
            var geolocation = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };
            var circle = new google.maps.Circle({
              center: geolocation,
              radius: position.coords.accuracy
            });
            autocomplete.setBounds(circle.getBounds());
          });
        }
    }
	geolocate();
	initAutocomplete();
	this.setState({
	  address:nadd
    });
  }
  
  render() {
    return (
		<div>
          <PhoneComponent number={this.state.number} changeNumber={this.changeNumber.bind(this)} />
		  <AddressComponent address={this.state.address} add={this.state.add} zipcode={this.state.zipcode} city={this.state.city} state={this.state.state} street1={this.state.street1} street2={this.state.street2} changeAddress={this.changeAddress.bind(this)} />
    	</div>
    );
  }
}

export default App;
